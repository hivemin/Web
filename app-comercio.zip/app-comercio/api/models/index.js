const models = {
    usersModel: require('./nosql/user'),
    commerceModel: require('./nosql/commerce'),
    webpageModel: require('./nosql/webpage'),
}
module.exports = models